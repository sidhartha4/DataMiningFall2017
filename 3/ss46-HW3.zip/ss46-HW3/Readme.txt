1. Copy the content of any of the files from the ExtradatasetFolder to the data.txt file to run that dataset or you can copy paste your own dataset.

2. The code is run using python ss46_HW.py (python2.7 was used)

3. The input is read from data.txt

4. The output is stored in the file ss46-HW.txt

